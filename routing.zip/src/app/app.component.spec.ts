import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { RouterTestingModule } from '@angular/router/testing'
import {routes} from './app-routing.module'
import { Router } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { Location } from '@angular/common';
 describe('AppComponent', () => {
  let router:Router
  //let fixture: ComponentFixture<AppComponent>
  let location: Location
  beforeEach(() => TestBed.configureTestingModule({
    imports:[RouterTestingModule.withRoutes(routes)],
    declarations: [AppComponent,LoginComponent,RegisterComponent,UserdetailsComponent]
  }));
beforeEach(()=>{
  router=TestBed.inject(Router)
  router.initialNavigation()
  location=TestBed.inject(Location)
})
  /* it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'routing-demo'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('routing-demo');
  });

  it('should render title', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('.content span')?.textContent).toContain('routing-demo app is running!');
  }); */
  it('',()=>{
    const fixture = TestBed.createComponent(AppComponent);

    fixture.detectChanges();
    fixture.whenStable().then(()=>{
      expect(location.path()).toBe('/login')
    })
 
  })
});
