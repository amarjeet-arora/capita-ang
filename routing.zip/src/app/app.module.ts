import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { LandingpageComponent } from './landingpage/landingpage.component';
 import { ChildRouter } from './shared/child.routing';
import { AboutComponent } from './about/about.component';
import { AboutmeComponent } from './aboutme/aboutme.component';
import { AboutcompanyComponent } from './aboutcompany/aboutcompany.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { RouterGuardApp } from './shared/RouterApp.service';
import { AppRoutingModule } from './app-routing.module';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    UserdetailsComponent,
    PortfolioComponent,
    LandingpageComponent,
    AboutComponent,
    AboutmeComponent,
    AboutcompanyComponent,
    PagenotfoundComponent
  ],
  imports: [
    BrowserModule,AppRoutingModule,ChildRouter
  ],
  providers: [RouterGuardApp],
  bootstrap: [LandingpageComponent]
})
export class AppModule { }
