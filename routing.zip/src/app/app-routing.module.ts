import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { AboutComponent } from './about/about.component';
import { AboutmeComponent } from './aboutme/aboutme.component';
import { AboutcompanyComponent } from './aboutcompany/aboutcompany.component';
 

export const routes: Routes = [
  { path: '', redirectTo: 'login',pathMatch: 'full' },
  { path: 'userregister', redirectTo: 'register', pathMatch: 'full' },
  { path: 'clientregister', redirectTo: 'register', pathMatch: 'full' },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  {
    path: 'about',
    component: AboutComponent,
    children: [
      { path: 'aboutme', component: AboutmeComponent },
      { path: 'aboutcomp', component: AboutcompanyComponent },
    ],
  },
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
