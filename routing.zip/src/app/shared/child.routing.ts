import { RouterModule } from '@angular/router';

import { UserdetailsComponent } from '../userdetails/userdetails.component';
import { PortfolioComponent } from '../portfolio/portfolio.component';
import { RouterGuardApp } from './RouterApp.service';
import { PagenotfoundComponent } from '../pagenotfound/pagenotfound.component';

export const ChildRouter = RouterModule.forChild([
  { path: 'userdetails/:id/:action', component: UserdetailsComponent },
  {
    path: 'portfolio',
    component: PortfolioComponent,
    canActivate: [RouterGuardApp],
  },
  { path: '**', component: PagenotfoundComponent },
]);
