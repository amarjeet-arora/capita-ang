
import { Injectable } from '@angular/core'
import {CanActivate} from '@angular/router'
@Injectable()
export class RouterGuardApp implements CanActivate{

    canActivate(){
        alert('unauth access')
        return false
    }
    
}


