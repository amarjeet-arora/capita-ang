import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { validateUrl } from '../shared/url.validator';

@Component({
  selector: 'app-datadriven',
  templateUrl: './datadriven.component.html',
  styleUrls: ['./datadriven.component.css'],
})
export class DatadrivenComponent {
  myform: FormGroup;
  languages: string[] =["English","French","German"]
  genders=['male','female']
  firstName: FormControl;
  lastName: FormControl
  pass:FormControl;
  email: FormControl;
  city: FormControl
  language: FormControl
  url:FormControl

  createFormControl() {
    this.firstName = new FormControl('admin',Validators.required);
    this.lastName = new FormControl('',Validators.required);
    this.pass = new FormControl('',[Validators.required,Validators.minLength(6)]);
    this.email = new FormControl('',[Validators.required,this.emailDomainValidator]);
    this.city = new FormControl('');
    this.language= new FormControl("")
    this.url= new FormControl('',validateUrl)
  }
  createForm() {
    this.myform = new FormGroup({
      name: new FormGroup({
        firstName: this.firstName,
        lastName: this.lastName,
      }),
      pass:this.pass,
      email: this.email,
      city: this.city,
      language:this.language
    });
  }
  constructor() {
    this.createFormControl();
    this.createForm();
  }
  addUser() {
    console.log(this.myform.value);
  }
  emailDomainValidator(control:FormControl){
    let email= control.value
    if(email && email.indexOf("@") ! -1){
      let [_,domain]=email.split("@")
      if(domain !== "capita.com"){
        return {
          emailDomain :{
            parsedDomain: domain
          }
        }
      }
    }
    return null;
  }
  
   
}
