import { Component,Input } from '@angular/core';
import { UserData } from '../shared/userdata.service';
import { DepartmentData } from '../shared/department.service';

@Component({
  selector: 'header-app',
  templateUrl: './header.component.html',
})
export class Header {
  userdata;
  depData;
  
@Input()
  appname='angular-header'

  constructor(private ud: UserData,private dep:DepartmentData) {
    this.userdata = ud.loadUsers();
    this.depData=dep.loadDepts()
  }
}
