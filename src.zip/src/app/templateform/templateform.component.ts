import { Component } from '@angular/core';
import { UserformService } from '../shared/userform.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-templateform',
  templateUrl: './templateform.component.html',
  styleUrls: ['./templateform.component.css'],
})
export class TemplateformComponent {
  items: any[] = [];
  constructor(private us: UserformService) {
    this.loadUserFromDB()
  }
  addUser(nf: NgForm) {
    this.us.addUserToDB(nf.value);
  }
  
  loadUserFromDB() {
    this.us.loadUserFromDB().subscribe((data) => {
      const myarray = [];
      for (let key in data) {
        myarray.push(data[key]);
      }
      this.items = myarray;
    });
  }
}
