import { Component ,ComponentFactoryResolver,ViewChild,ViewContainerRef} from '@angular/core';
import { MessageComponent } from '../message/message.component';

@Component({
  selector: 'app-message-main',
  templateUrl: './message-main.component.html',
  styleUrls: ['./message-main.component.css']
})
export class MessageMainComponent {
  title='welcome Main'
  componentRef:any
@ViewChild('messageContainer',{read:ViewContainerRef})entry: ViewContainerRef
  constructor(private resolver: ComponentFactoryResolver){

  }
  createComponent(message) {
  
    this.entry.clear()
    const factory= this.resolver.resolveComponentFactory(MessageComponent)
    this.componentRef=this.entry.createComponent(factory)
    this.componentRef.instance.message =message
  }

}
