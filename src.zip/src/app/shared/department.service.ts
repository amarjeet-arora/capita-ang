import { Injectable } from '@angular/core';

@Injectable()
export class DepartmentData {
  loadDepts(): string[] {
    return ['HR', 'Finance', 'IT'];
  }
}
