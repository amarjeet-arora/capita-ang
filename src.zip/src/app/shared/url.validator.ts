import { FormControl } from '@angular/forms';

export function validateUrl(control: FormControl) {
  if (!control.value.startsWith('https') || control.value.include('.io')) {
    return {
      invalidURL: true,
    };
  }
  return null;
}
