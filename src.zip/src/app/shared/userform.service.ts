import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class UserformService {

  constructor(private http:HttpClient){}

   addUserToDB(data:any){
     
    this.http.post('https://capita-angu-default-rtdb.firebaseio.com/userdata.json',data)
     .subscribe((data)=>{
      console.log(data);
      
     })
     
   }
   loadUserFromDB(){
   return this.http.get('https://capita-angu-default-rtdb.firebaseio.com/userdata.json')
    
   }
}
