import {
  Directive,
  ElementRef,
  HostBinding,
  HostListener,
  Renderer2,
} from '@angular/core';

@Directive({
  selector: '[cc]',
})
export class ColorChanger {
  /*  constructor(ef:ElementRef,ren:Renderer2){
        ren.setStyle(ef.nativeElement,'backgroundColor','pink')
    } */

  defaultColor = 'white';
  @HostListener('mouseover')
  addColor() {
    this.defaultColor = 'pink';
  }
  @HostListener('mouseleave')
  removeColor() {
    this.defaultColor = 'white';
  }
  @HostBinding('style.backgroundColor')
  get applyColor() {
    return this.defaultColor;
  }
}
