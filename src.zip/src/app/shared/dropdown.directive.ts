import { Directive, HostBinding, HostListener } from '@angular/core';
@Directive({
  selector: '[dropdown]',
})
export class DropDownApp {
  isOpen = false;

  @HostListener('click')
  openTab() {
    this.isOpen = true;
  }
  @HostListener('mouseleave')
  closeTab() {
    this.isOpen = false;
  }
  @HostBinding('class.open')
  get isOpened() {
    return this.isOpen;
  }
}
