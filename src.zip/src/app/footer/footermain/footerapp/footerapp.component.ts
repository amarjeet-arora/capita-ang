import { Component } from '@angular/core';

@Component({
  selector: 'app-footerapp',
  templateUrl: './footerapp.component.html',
  styleUrls: ['./footerapp.component.css']
})
export class FooterappComponent {

}
