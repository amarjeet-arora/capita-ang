import { Component } from "@angular/core";

@Component({
    selector:'main-app',
    templateUrl: './mainapp.component.html'
})
export class MainApp {

    newvalue='data from parent'
}