import { Component, ViewChild } from '@angular/core';
import { NumberCompComponent } from '../number-comp/number-comp.component';
 

@Component({
  selector: 'app-number-parent',
  templateUrl: './number-parent.component.html',
  styleUrls: ['./number-parent.component.css']
})
export class NumberParentComponent {
@ViewChild(NumberCompComponent)
  private nc:NumberCompComponent

  inc(){
    this.nc.increment()
  }
dec(){
  this.nc.decrement()
}
}
