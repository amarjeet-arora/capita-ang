import { Component } from '@angular/core';

@Component({
  selector: 'app-demoapp',
  templateUrl: './demoapp.component.html',
  styleUrls: ['./demoapp.component.css'],
})
export class DemoappComponent {
  mycity = 'mumbai';
  myprofile =
    'https://imgv3.fotor.com/images/blog-cover-image/10-profile-picture-ideas-to-make-you-stand-out.jpg';

  callme() {
    alert('i am called...!');
  }
  getColor(country: any) {
    switch (country) {
      case 'UK':
        return 'green';
      case 'USA':
        return 'blue';
      case 'INDIA':
        return 'purple';
      default:
        return 'nothing';
    }
  }
  people: any[] = [
    {
      name: 'Douglas',
      country: 'UK',
    },
    {
      name: 'mcleod',
      country: 'USA',
    },
    {
      name: 'Shina',
      country: 'INDIA',
    },
  ];
}
