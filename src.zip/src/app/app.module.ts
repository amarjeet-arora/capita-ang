import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MainApp } from './mainapp/mainapp.component';
import { Header } from './header/header.component';
import { Footer } from './footer/footer.component';
import { UserData } from './shared/userdata.service';
import { DepartmentData } from './shared/department.service';
import { DemoappComponent } from './demoapp/demoapp.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { NumberCompComponent } from './number-comp/number-comp.component';
import { NumberParentComponent } from './number-parent/number-parent.component';
import { TemplateformComponent } from './templateform/templateform.component'
import {HttpClientModule} from '@angular/common/http';
import { DatadrivenComponent } from './datadriven/datadriven.component';
import { MessageComponent } from './message/message.component';
import { MessageMainComponent } from './message-main/message-main.component';
import { FooterappComponent } from './footer/footermain/footerapp/footerapp.component';
import { PipedemoComponent } from './pipedemo/pipedemo.component'
import { Summary } from './shared/summary.pipe';
import { TempConverter } from './shared/TempConverter.pipe';
import { SearchfilterPipe } from './searchfilter.pipe';
import { ColorChanger } from './shared/colorchanger.directive';
@NgModule({
  // it contains all the component,pipe,directive used in application
  declarations: [
    AppComponent,
    MainApp,
    Header,
    Footer,
    DemoappComponent,
    NumberCompComponent,
    NumberParentComponent,
    TemplateformComponent,
    DatadrivenComponent,
    MessageComponent,
    MessageMainComponent,
    FooterappComponent,
    PipedemoComponent,
    ColorChanger,
  Summary,
  TempConverter,
  SearchfilterPipe
  ],
  // contains all the modules
  imports: [
    BrowserModule,FormsModule,HttpClientModule,ReactiveFormsModule
  ],
  // contains service are by default singleton
  providers: [UserData,DepartmentData],
  // welcome file
  bootstrap: [AppComponent]
})
export class AppModule { }
