import { Component } from '@angular/core';

@Component({
  selector: 'app-pipedemo',
  templateUrl: './pipedemo.component.html',
  styleUrls: ['./pipedemo.component.css']
})
export class PipedemoComponent {

  employeeList=[]
  userdata={
    uname: 'administrator',
    income: 99889,
    rating : 4.88679,
    DOJ: new Date('11/11/2011'),
    details: 'this is angular custom pipe used in app'
  }
  cel:number
  far:number

  constructor(){
    this.employeeList=[
      {
        firstName: 'adam',
        lastName: 'sonap',
        address :'89 wall st'
      },
      {
        firstName: 'tailor',
        lastName: 'sonap',
        address :'89 wall st'
      },
      {
        firstName: 'adam',
        lastName: 'sonap',
        address :'89 wall st'
      },
    ]
  }
  searchText
}
